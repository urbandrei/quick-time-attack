import { CANVAS_WIDTH, CANVAS_HEIGHT } from './game.js';

const HALF_W = CANVAS_WIDTH / 2;
const HALF_H = CANVAS_HEIGHT / 2;

export class Camera {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.targetX = 0;
    this.targetY = 0;
    this.zoom = 1;
    this.targetZoom = 1;
    this.lerpSpeed = 8;
    this.leadFactor = 12;
    this.zoomLerpSpeed = 5;

    // Shake state
    this.shakeTrauma = 0;
    this.shakeOffsetX = 0;
    this.shakeOffsetY = 0;
    this.shakeDecay = 4; // trauma units per second
    this.shakeMaxOffset = 12; // max pixel displacement
  }

  /** Snap camera to a position immediately (no lerp). */
  snapTo(x, y) {
    this.x = this.targetX = x;
    this.y = this.targetY = y;
  }

  update(dt, player, mouseScreenPos) {
    // Compute lead offset from mouse position relative to canvas center
    let leadX = 0;
    let leadY = 0;
    if (mouseScreenPos) {
      let mdx = mouseScreenPos.x - HALF_W;
      let mdy = mouseScreenPos.y - HALF_H;
      const dist = Math.sqrt(mdx * mdx + mdy * mdy);
      if (dist > 1) {
        leadX = (mdx / dist) * this.leadFactor;
        leadY = (mdy / dist) * this.leadFactor;
      }
    }

    // Target = player center + lead offset
    this.targetX = player.x + leadX;
    this.targetY = player.y + leadY;

    // Lerp position toward target
    this.x += (this.targetX - this.x) * this.lerpSpeed * dt;
    this.y += (this.targetY - this.y) * this.lerpSpeed * dt;

    // Lerp zoom
    this.zoom += (this.targetZoom - this.zoom) * this.zoomLerpSpeed * dt;

    this._updateShake(dt);
  }

  applyTransform(ctx) {
    ctx.save();
    if (this.zoom !== 1) {
      ctx.translate(HALF_W, HALF_H);
      ctx.scale(this.zoom, this.zoom);
      ctx.translate(-HALF_W, -HALF_H);
    }
    ctx.translate(HALF_W - this.x + this.shakeOffsetX, HALF_H - this.y + this.shakeOffsetY);
  }

  removeTransform(ctx) {
    ctx.restore();
  }

  /** Convert screen coordinates to world coordinates. */
  screenToWorld(screenX, screenY) {
    const wx = (screenX - HALF_W) / this.zoom + this.x;
    const wy = (screenY - HALF_H) / this.zoom + this.y;
    return { x: wx, y: wy };
  }

  /**
   * Add trauma to trigger screen shake. Trauma is squared to drive offset,
   * giving small hits a subtle shake and big hits a violent one.
   * @param {number} amount - Trauma to add (0–1 range, clamped)
   */
  shake(amount) {
    this.shakeTrauma = Math.min(1, this.shakeTrauma + amount);
  }

  _updateShake(dt) {
    if (this.shakeTrauma <= 0) {
      this.shakeOffsetX = 0;
      this.shakeOffsetY = 0;
      return;
    }

    const intensity = this.shakeTrauma * this.shakeTrauma; // squared for curve
    this.shakeOffsetX = (Math.random() * 2 - 1) * this.shakeMaxOffset * intensity;
    this.shakeOffsetY = (Math.random() * 2 - 1) * this.shakeMaxOffset * intensity;

    this.shakeTrauma = Math.max(0, this.shakeTrauma - this.shakeDecay * dt);
  }

  /** Stub: punch zoom for juice (Step 64). */
  zoomPunch(intensity) {
    this.targetZoom = 1 + (intensity || 0.05);
  }

  /** Stub: offset kick from a world point (Step 64). */
  kick(fromX, fromY, strength) {
    // Will apply a directional offset toward the camera — implemented later
  }
}
