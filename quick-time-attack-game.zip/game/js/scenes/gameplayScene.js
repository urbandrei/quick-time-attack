import { CANVAS_WIDTH, CANVAS_HEIGHT } from '../game.js';
import { input } from '../input.js';
import { PauseScene } from './pauseScene.js';
import { GameOverScene } from './gameOverScene.js';
import { QTEScene } from './qteScene.js';
import { Level } from '../levels/level.js';
import { LevelManager, CHALLENGE_TYPES } from '../levels/levelManager.js';
import { getWallSegments, checkCircleCollision, checkAABB } from '../collision.js';
import { Player } from '../player.js';
import { Camera } from '../camera.js';
import { BulletPool } from '../bullet.js';
import { Enemy } from '../enemies/enemy.js';
import { Bat } from '../enemies/bat.js';
import { Gopher } from '../enemies/gopher.js';
import { SpinningTop } from '../enemies/spinningTop.js';
import { Letter } from '../enemies/letter.js';
import { Cowboy } from '../enemies/cowboy.js';
import { Controller } from '../enemies/controller.js';
import { Heart } from '../enemies/heart.js';
import { Clock } from '../enemies/clock.js';
import { HUD } from '../hud.js';

// Map spawn-point type → class (fall back to base Enemy for unimplemented types)
const ENEMY_CLASSES = {
  bat: Bat,
  gopher: Gopher,
  spinningTop: SpinningTop,
  letter: Letter,
  cowboy: Cowboy,
  controller: Controller,
  heart: Heart,
  clock: Clock,
};

// Number of frames within which a bullet hit is nullified by a QTE trigger
const QTE_PRIORITY_FRAMES = 3;

// QTE blast constants
const BLAST_RADIUS = 240;          // half room width
const KNOCKBACK_FORCE = 400;       // px/s initial impulse
const RETREAT_KNOCKBACK_FORCE = 300; // enemy retreat force on QTE failure

// Level timer
const LEVEL_TIME_LIMIT = 30; // seconds

// Exit hole
const EXIT_HOLE_RADIUS = 24;
const EXIT_HOLE_COLOR = '#050510';
const EXIT_HOLE_BORDER_COLOR = '#44ff88';
const EXIT_HOLE_FLEE_COLOR = '#ff4444';
const EXIT_HOLE_BORDER_WIDTH = 3;

// Challenge room
const CHALLENGE_SPAWN_INTERVAL = 3;   // seconds between enemy spawns
const CHALLENGE_SAFE_TIME = 5;        // last N seconds the hole turns green
const CHALLENGE_SPAWN_MARGIN = 0.15;  // keep spawns away from edges (0–1)

// Boss
const BOSS_MAX_HP = 5;
const BOSS_SPAWN_INTERVAL = 4;        // seconds between enemy spawns

// Key follow / homing
const KEY_FOLLOW_SPEED = 3;         // lerp factor while trailing player
const KEY_HOMING_ACCEL = 600;       // px/s² acceleration toward hole
const KEY_ARRIVAL_DIST = 4;         // px — close enough to count as arrived

// Transition animation
const FALL_DURATION = 0.4;     // seconds — player shrinks downward into hole
const LAND_DURATION = 0.35;    // seconds — player drops from above
const SQUASH_DURATION = 0.12;  // seconds — impact squash recovery
const LAND_DROP_HEIGHT = 300;  // pixels above landing point

class GameplayScene {
  constructor(game) {
    this.game = game;
  }

  enter() {
    // Guard against re-init when returning from overlay (pause, QTE, game over)
    if (this._initialized) return;
    this._initialized = true;

    this.levelManager = new LevelManager();
    this.challengeDisplayName = '';
    this.hud = new HUD();
    this.transition = null;
    this._initLevel();
  }

  exit() {}

  /**
   * Build (or rebuild) the current level: layout, enemies, timer, exit state.
   * Preserves player lives and levelDepth across levels.
   */
  _initLevel() {
    // Advance to next level and get layout + challenge info
    const levelInfo = this.levelManager.advance();
    this.challengeDisplayName = levelInfo.displayName;
    this.level = new Level(levelInfo.layout);
    this.walls = getWallSegments(this.level);

    // Create or reposition the player
    if (!this.player) {
      this.player = new Player({
        x: this.level.playerStartX,
        y: this.level.playerStartY,
      });
    } else {
      this.player.x = this.level.playerStartX;
      this.player.y = this.level.playerStartY;
    }

    // Camera — snap to player immediately so there's no lerp-from-origin
    this.camera = new Camera();
    this.camera.snapTo(this.player.x, this.player.y);

    // Bullet pool
    this.bullets = new BulletPool();

    // Spawn enemies from room spawn-point data
    this.enemies = [];
    for (const room of this.level.rooms) {
      for (const sp of room.getWorldSpawnPoints()) {
        const EnemyClass = ENEMY_CLASSES[sp.type] || Enemy;
        const enemy = new EnemyClass({ x: sp.x, y: sp.y, enemyType: sp.type });
        if (enemy.enemyType === 'gopher') {
          enemy.roomBounds = {
            x: room.floorX, y: room.floorY,
            width: room.floorWidth, height: room.floorHeight,
          };
        }
        this.enemies.push(enemy);
      }
    }

    // Relocate hearts to starting room and assign pathfinding
    const startRoom = this.level.rooms[this.level.startRoomIndex];
    const farthestRoomIndex = this.level.getFarthestRoom(this.level.startRoomIndex);

    for (const enemy of this.enemies) {
      if (enemy.enemyType === 'heart') {
        const path = this.level.findPath(this.level.startRoomIndex, farthestRoomIndex);

        // Place near the hallway exit in the starting room
        let placed = false;
        if (path.length > 0) {
          const hw = path[0]; // first waypoint = hallway midpoint
          for (const h of this.level.hallways) {
            const hmx = h.floor.x + h.floor.w / 2;
            const hmy = h.floor.y + h.floor.h / 2;
            if (Math.abs(hmx - hw.x) < 1 && Math.abs(hmy - hw.y) < 1) {
              const opening = h.openings.find(o => o.roomIndex === this.level.startRoomIndex);
              if (opening) {
                const oc = (opening.start + opening.end) / 2;
                const margin = 32;
                if (opening.side === 'right') {
                  enemy.x = startRoom.floorX + startRoom.floorWidth - margin;
                  enemy.y = oc;
                } else if (opening.side === 'left') {
                  enemy.x = startRoom.floorX + margin;
                  enemy.y = oc;
                } else if (opening.side === 'bottom') {
                  enemy.x = oc;
                  enemy.y = startRoom.floorY + startRoom.floorHeight - margin;
                } else if (opening.side === 'top') {
                  enemy.x = oc;
                  enemy.y = startRoom.floorY + margin;
                }
                placed = true;
              }
              break;
            }
          }
        }
        if (!placed) {
          enemy.x = startRoom.floorX + startRoom.floorWidth / 2;
          enemy.y = startRoom.floorY + startRoom.floorHeight / 2;
        }

        enemy.setPath(path);
      }
    }

    // QTE priority tracking
    this.frameCount = 0;
    this.bulletDamageFrame = -Infinity;
    this.qteActive = false;

    // Level timer
    this.levelTimer = LEVEL_TIME_LIMIT;

    // Challenge completion & exit hole
    this.challengeComplete = false;
    this.exitHole = null;
    this.gameOverPushed = false;

    // Key item (Find the Key challenge)
    this.keyItem = null;
    this.hasKey = false;
    if (levelInfo.challengeType === CHALLENGE_TYPES.FIND_THE_KEY && levelInfo.keyRoomIndex != null) {
      const keyRoom = this.level.rooms[levelInfo.keyRoomIndex];
      this.keyItem = {
        x: keyRoom.floorX + keyRoom.floorWidth / 2,
        y: keyRoom.floorY + keyRoom.floorHeight / 2,
        radius: 10,
        collected: false,
        homing: false,
        homingSpeed: 0,
      };
    }

    // Coffee Break — exit open immediately, no timer
    if (levelInfo.challengeType === CHALLENGE_TYPES.COFFEE_BREAK) {
      this.challengeComplete = true;
      this.exitHole = {
        x: this.level.exitHoleX,
        y: this.level.exitHoleY,
        radius: EXIT_HOLE_RADIUS,
      };
      this.timerActive = false;
    } else {
      this.timerActive = true;
    }

    // Boss — continuous spawning, 5 QTEs to win
    this.bossHP = 0;
    this.bossMaxHP = 0;
    this.bossSpawnTimer = 0;
    if (levelInfo.challengeType === CHALLENGE_TYPES.BOSS) {
      this.bossHP = BOSS_MAX_HP;
      this.bossMaxHP = BOSS_MAX_HP;
      this.bossSpawnTimer = BOSS_SPAWN_INTERVAL; // spawn first enemy immediately
    }

    // Challenge room — hole open from start (red = flee), trickle-spawn enemies
    this.challengeFleeMode = false;
    this.challengeSpawnTimer = 0;
    if (levelInfo.challengeType === CHALLENGE_TYPES.CHALLENGE) {
      this.challengeFleeMode = true;
      this.challengeComplete = true; // hole exists from start
      this.exitHole = {
        x: this.level.exitHoleX,
        y: this.level.exitHoleY,
        radius: EXIT_HOLE_RADIUS,
      };
    }

    // Power Up — generators in each cardinal room
    this.generators = [];
    if (levelInfo.challengeType === CHALLENGE_TYPES.POWER_UP) {
      for (let i = 0; i < this.level.rooms.length; i++) {
        if (i === this.level.startRoomIndex) continue;
        const room = this.level.rooms[i];
        this.generators.push({
          roomIndex: i,
          x: room.floorX + room.floorWidth / 2,
          y: room.floorY + room.floorHeight / 2,
          radius: 16,
          completed: false,
        });
      }
    }
  }

  /**
   * Start the falling transition into the exit hole.
   */
  _startTransition() {
    this.transition = {
      phase: 'falling',
      timer: 0,
      startX: this.player.x,
      startY: this.player.y,
      holeX: this.exitHole.x,
      holeY: this.exitHole.y,
    };
  }

  update(dt) {
    // ── Transition animation (overrides normal gameplay) ───────────────
    if (this.transition) {
      this._updateTransition(dt);
      return;
    }

    if (input.isActionJustPressed('pause')) {
      this.game.pushScene(new PauseScene(this.game));
      return;
    }

    this.frameCount++;

    // ── Level timer countdown (paused during QTE, disabled for coffee break) ──
    if (!this.qteActive && this.timerActive) {
      this.levelTimer -= dt;
      if (this.levelTimer <= 0) {
        this.levelTimer = 0;
        if (!this.gameOverPushed) {
          this.player.dead = true;
          this.gameOverPushed = true;
          this.game.pushScene(new GameOverScene(this.game, { levelDepth: this.levelManager.levelDepth }));
        }
        return;
      }
    }

    this.player.update(dt, this.walls);
    this.bullets.update(dt, this.walls);

    // Update enemies
    for (const enemy of this.enemies) {
      enemy.update(dt, this.walls, this.player, this.bullets);
    }

    // ── Player-enemy QTE collision (AABB vs AABB, checked FIRST) ──────
    // QTE takes priority over bullet damage within a 3-frame window.
    if (!this.player.dead && !this.player.invulnerable && !this.qteActive) {
      const qteEnemy = this._checkQTECollision();

      if (qteEnemy) {
        // Nullify recent bullet damage if within the priority window
        if (this.frameCount - this.bulletDamageFrame <= QTE_PRIORITY_FRAMES) {
          this.player.undoDamage();
        }

        this._triggerQTE(qteEnemy);
        return; // skip bullet checks this frame
      }
    }

    // ── Player-generator collision (Power Up) ───────────────────────
    if (!this.player.dead && !this.qteActive && this.generators.length > 0) {
      for (const gen of this.generators) {
        if (gen.completed) continue;
        const dx = this.player.x - gen.x;
        const dy = this.player.y - gen.y;
        if (dx * dx + dy * dy < (this.player.wallRadius + gen.radius) ** 2) {
          this._triggerGeneratorQTE(gen);
          return;
        }
      }
    }

    // ── Bullet-player collision (circle vs circle) ────────────────────
    if (!this.player.dead && !this.player.invulnerable) {
      for (let i = 0; i < this.bullets.pool.length; i++) {
        const b = this.bullets.pool[i];
        if (!b.active) continue;

        const result = checkCircleCollision(
          b.x, b.y, b.radius,
          this.player.x, this.player.y, this.player.bulletRadius
        );

        if (result.hit) {
          b.active = false;
          if (this.player.damage()) {
            this.bulletDamageFrame = this.frameCount;
          }
        }
      }
    }

    // ── Lunging bat vs player (bat acts as projectile during lunge) ───
    if (!this.player.dead && !this.player.invulnerable) {
      for (const enemy of this.enemies) {
        if (!enemy.active || !enemy.isLunging) continue;

        const result = checkCircleCollision(
          enemy.x, enemy.y, enemy.lungeRadius,
          this.player.x, this.player.y, this.player.bulletRadius
        );

        if (result.hit) {
          this.player.damage();
          break; // only one damage per frame
        }
      }
    }

    this.camera.update(dt, this.player, input.getMousePos());

    // ── Challenge room: trickle-spawn enemies + flee→safe transition ──
    if (this.challengeFleeMode || this.levelManager.challengeType === CHALLENGE_TYPES.CHALLENGE) {
      // Spawn a new bat at a random floor position on interval
      if (this.challengeFleeMode) {
        this.challengeSpawnTimer += dt;
        if (this.challengeSpawnTimer >= CHALLENGE_SPAWN_INTERVAL) {
          this.challengeSpawnTimer -= CHALLENGE_SPAWN_INTERVAL;
          this._spawnChallengeEnemy();
        }
      }

      // Transition from flee (red) to safe (green) in last N seconds
      if (this.challengeFleeMode && this.levelTimer <= CHALLENGE_SAFE_TIME) {
        this.challengeFleeMode = false;
      }
    }

    // ── Boss: continuous enemy spawning ────────────────────────────────
    if (this.levelManager.challengeType === CHALLENGE_TYPES.BOSS && this.bossHP > 0) {
      this.bossSpawnTimer += dt;
      if (this.bossSpawnTimer >= BOSS_SPAWN_INTERVAL) {
        this.bossSpawnTimer -= BOSS_SPAWN_INTERVAL;
        this._spawnChallengeEnemy();
      }
    }

    // ── Challenge completion check ────────────────────────────────────
    if (!this.challengeComplete) {
      const type = this.levelManager.challengeType;

      if (type === CHALLENGE_TYPES.FIND_THE_KEY) {
        // Pick up key
        if (this.keyItem && !this.keyItem.collected) {
          const dx = this.player.x - this.keyItem.x;
          const dy = this.player.y - this.keyItem.y;
          if (dx * dx + dy * dy < (this.player.wallRadius + this.keyItem.radius) ** 2) {
            this.keyItem.collected = true;
            this.hasKey = true;
          }
        }
        // Player enters starting room with key → key starts homing to hole
        if (this.hasKey && this.keyItem && !this.keyItem.homing
            && this._isPlayerInRoom(this.level.startRoomIndex)) {
          this.keyItem.homing = true;
          this.keyItem.homingSpeed = 0;
        }
      } else if (type !== CHALLENGE_TYPES.BOSS && type !== CHALLENGE_TYPES.POWER_UP) {
        // Default: kill all enemies (boss/power-up completion handled via QTE callbacks)
        if (this.enemies.every(e => !e.active)) {
          this.challengeComplete = true;
          this.exitHole = {
            x: this.level.exitHoleX,
            y: this.level.exitHoleY,
            radius: EXIT_HOLE_RADIUS,
          };
        }
      }
    }

    // ── Player-exit hole collision ────────────────────────────────────
    if (this.exitHole && !this.player.dead) {
      const dx = this.player.x - this.exitHole.x;
      const dy = this.player.y - this.exitHole.y;
      const distSq = dx * dx + dy * dy;
      const threshold = this.exitHole.radius + this.player.wallRadius;
      if (distSq < threshold * threshold) {
        // Fleeing a challenge room costs a life
        if (this.challengeFleeMode) {
          this.player.damage();
        }
        this._startTransition();
        return;
      }
    }

    // Update key follow / homing
    if (this.keyItem && this.keyItem.collected) {
      if (this.keyItem.homing) {
        // Accelerate toward exit hole position
        const tx = this.level.exitHoleX;
        const ty = this.level.exitHoleY;
        const dx = tx - this.keyItem.x;
        const dy = ty - this.keyItem.y;
        const dist = Math.sqrt(dx * dx + dy * dy);

        if (dist < KEY_ARRIVAL_DIST) {
          // Key arrived — open the hole, remove key
          this.challengeComplete = true;
          this.exitHole = {
            x: this.level.exitHoleX,
            y: this.level.exitHoleY,
            radius: EXIT_HOLE_RADIUS,
          };
          this.keyItem = null;
          this.camera.shake(0.4);
        } else {
          this.keyItem.homingSpeed += KEY_HOMING_ACCEL * dt;
          const step = Math.min(this.keyItem.homingSpeed * dt, dist);
          this.keyItem.x += (dx / dist) * step;
          this.keyItem.y += (dy / dist) * step;
        }
      } else {
        // Lazy trail behind player
        this.keyItem.x += (this.player.x - this.keyItem.x) * KEY_FOLLOW_SPEED * dt;
        this.keyItem.y += (this.player.y - this.keyItem.y) * KEY_FOLLOW_SPEED * dt;
      }
    }

    // Update HUD
    this.hud.update(dt, {
      lives: this.player.lives,
      timer: this.levelTimer,
      levelDepth: this.levelManager.levelDepth,
      challengeType: this.challengeDisplayName,
      timerActive: this.timerActive,
      bossHP: this.bossHP,
      bossMaxHP: this.bossMaxHP,
      generatorsDone: this.generators.filter(g => g.completed).length,
      generatorsTotal: this.generators.length,
    });

    // Check for game over after player update
    if (this.player.dead && !this.gameOverPushed) {
      this.gameOverPushed = true;
      this.game.pushScene(new GameOverScene(this.game, { levelDepth: this.levelManager.levelDepth }));
    }
  }

  // ── Transition logic ──────────────────────────────────────────────────

  _updateTransition(dt) {
    this.transition.timer += dt;

    switch (this.transition.phase) {
      case 'falling':
        if (this.transition.timer >= FALL_DURATION) {
          // Rebuild level for next floor
          this._initLevel();
          // Switch to landing phase
          this.transition.phase = 'landing';
          this.transition.timer = 0;
          // Update HUD immediately with new depth/timer
          this.hud.update(0, {
            lives: this.player.lives,
            timer: this.levelTimer,
            levelDepth: this.levelManager.levelDepth,
            challengeType: this.challengeDisplayName,
            timerActive: this.timerActive,
            bossHP: this.bossHP,
            bossMaxHP: this.bossMaxHP,
            generatorsDone: this.generators.filter(g => g.completed).length,
            generatorsTotal: this.generators.length,
          });
        }
        break;

      case 'landing':
        if (this.transition.timer >= LAND_DURATION) {
          // Impact — squash + camera shake
          this.transition.phase = 'squash';
          this.transition.timer = 0;
          this.camera.shake(0.6);
        }
        // Fall through to tick shake
        this.camera._updateShake(dt);
        break;

      case 'squash':
        this.camera._updateShake(dt);
        if (this.transition.timer >= SQUASH_DURATION) {
          this.transition = null; // done — resume gameplay
        }
        break;
    }
  }

  /**
   * Check if player center is within a room's floor rect.
   */
  _isPlayerInRoom(roomIndex) {
    const room = this.level.rooms[roomIndex];
    const { x, y } = this.player;
    return x >= room.floorX && x <= room.floorX + room.floorWidth
        && y >= room.floorY && y <= room.floorY + room.floorHeight;
  }

  /**
   * Spawn a bat at a random floor position for Challenge room trickle waves.
   */
  _spawnChallengeEnemy() {
    const room = this.level.rooms[0];
    const m = CHALLENGE_SPAWN_MARGIN;
    const rx = m + Math.random() * (1 - 2 * m);
    const ry = m + Math.random() * (1 - 2 * m);
    const pos = room.spawnToWorld(rx, ry);
    const bat = new Bat({ x: pos.x, y: pos.y, enemyType: 'bat' });
    this.enemies.push(bat);
  }

  /**
   * Check for AABB overlap between player and any QTE-able enemy.
   * Returns the first overlapping enemy, or null.
   */
  _checkQTECollision() {
    const pAABB = {
      x: this.player.x - this.player.width / 2,
      y: this.player.y - this.player.height / 2,
      w: this.player.width,
      h: this.player.height,
    };

    for (const enemy of this.enemies) {
      if (!enemy.active || !enemy.canTriggerQTE) continue;

      const eAABB = {
        x: enemy.x - enemy.width / 2,
        y: enemy.y - enemy.height / 2,
        w: enemy.width,
        h: enemy.height,
      };

      if (checkAABB(pAABB, eAABB)) {
        return enemy;
      }
    }
    return null;
  }

  /**
   * Push the QTE scene for the given enemy.
   */
  _triggerQTE(enemy) {
    this.qteActive = true;

    this.game.pushScene(new QTEScene(this.game, {
      enemy,
      onSuccess: (e) => {
        const blastX = e.x;
        const blastY = e.y;

        // Kill the QTE target
        e.takeDamage();

        // Destroy bullets in blast radius
        this.bullets.destroyInRadius(blastX, blastY, BLAST_RADIUS);

        // Knockback nearby enemies
        for (const other of this.enemies) {
          if (!other.active || other === e) continue;
          const dx = other.x - blastX;
          const dy = other.y - blastY;
          if (dx * dx + dy * dy <= BLAST_RADIUS * BLAST_RADIUS) {
            other.applyKnockback(blastX, blastY, KNOCKBACK_FORCE);
          }
        }

        // Heart: grant extra life (capped at 5)
        if (e.enemyType === 'heart') {
          this.player.addLife();
        }

        // Clock: grant +5 seconds to level timer
        if (e.enemyType === 'clock') {
          this.levelTimer += 5;
        }

        // Boss: decrement HP, open exit when defeated
        if (this.levelManager.challengeType === CHALLENGE_TYPES.BOSS && this.bossHP > 0) {
          this.bossHP--;
          if (this.bossHP <= 0) {
            this.challengeComplete = true;
            this.exitHole = {
              x: this.level.exitHoleX,
              y: this.level.exitHoleY,
              radius: EXIT_HOLE_RADIUS,
            };
          }
        }

        this.qteActive = false;
      },
      onFail: (e) => {
        // Player takes damage (loses life + becomes invulnerable for 1s)
        this.player.damage();

        // Enemy retreats away from player
        e.applyKnockback(this.player.x, this.player.y, RETREAT_KNOCKBACK_FORCE);

        this.qteActive = false;
      },
    }));
  }

  /**
   * Push a TapQTE for a generator (Power Up challenge).
   */
  _triggerGeneratorQTE(generator) {
    this.qteActive = true;
    const genProxy = {
      color: '#ffaa00',
      enemyType: 'generator',
      qteType: 'tap',
    };

    this.game.pushScene(new QTEScene(this.game, {
      enemy: genProxy,
      onSuccess: () => {
        generator.completed = true;
        if (this.generators.every(g => g.completed)) {
          this.challengeComplete = true;
          this.exitHole = {
            x: this.level.exitHoleX,
            y: this.level.exitHoleY,
            radius: EXIT_HOLE_RADIUS,
          };
        }
        this.qteActive = false;
      },
      onFail: () => {
        this.player.damage();
        this.qteActive = false;
      },
    }));
  }

  // ── Rendering ─────────────────────────────────────────────────────────

  render(ctx) {
    // Clear canvas background (screen-space, before camera transform)
    ctx.fillStyle = '#0e0e1a';
    ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT);

    // --- World-space rendering (affected by camera) ---
    this.camera.applyTransform(ctx);

    // Draw level (rooms + hallways)
    this.level.render(ctx);

    // Draw exit hole (on floor, before entities)
    if (this.exitHole) {
      this._renderExitHole(ctx);
    }

    // Draw key item (on floor before entities, follows player when collected)
    if (this.keyItem) {
      this._renderKeyItem(ctx);
    }

    // Draw generators (on floor before entities)
    for (const gen of this.generators) {
      this._renderGenerator(ctx, gen);
    }

    // Draw enemies
    for (const enemy of this.enemies) {
      if (enemy.active) enemy.render(ctx);
    }

    // Draw bullets
    this.bullets.render(ctx);

    // Draw player (with transition effects if active)
    if (this.transition) {
      this._renderTransitionPlayer(ctx);
    } else {
      this.player.render(ctx);
    }

    this.camera.removeTransform(ctx);

    // --- Screen-space rendering (HUD, unaffected by camera) ---
    this.hud.render(ctx);
  }

  _renderKeyItem(ctx) {
    const { x, y, radius } = this.keyItem;
    ctx.fillStyle = '#ffdd44';
    ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
    ctx.strokeStyle = '#aa8800';
    ctx.lineWidth = 2;
    ctx.strokeRect(x - radius, y - radius, radius * 2, radius * 2);
  }

  _renderGenerator(ctx, gen) {
    const { x, y, radius } = gen;

    if (gen.completed) {
      ctx.fillStyle = '#44ff88';
      ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
    } else {
      ctx.fillStyle = '#ffaa00';
      ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);

      const pulse = 0.6 + 0.4 * Math.sin(performance.now() / 300);
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.globalAlpha = pulse;
      ctx.strokeRect(x - radius, y - radius, radius * 2, radius * 2);
      ctx.globalAlpha = 1;
    }
  }

  _renderExitHole(ctx) {
    const { x, y, radius } = this.exitHole;

    // Dark hole fill
    ctx.fillStyle = EXIT_HOLE_COLOR;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fill();

    // Pulsing border — red during challenge flee mode, green otherwise
    const pulse = 0.6 + 0.4 * Math.sin(performance.now() / 300);
    ctx.strokeStyle = this.challengeFleeMode ? EXIT_HOLE_FLEE_COLOR : EXIT_HOLE_BORDER_COLOR;
    ctx.lineWidth = EXIT_HOLE_BORDER_WIDTH;
    ctx.globalAlpha = pulse;
    ctx.beginPath();
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;
  }

  _renderTransitionPlayer(ctx) {
    const tr = this.transition;
    const { width, height, color } = this.player;
    let drawX, drawY, scaleX, scaleY;

    switch (tr.phase) {
      case 'falling': {
        const t = Math.min(tr.timer / FALL_DURATION, 1);
        const eased = t * t; // ease-in: accelerates downward
        drawX = _lerp(tr.startX, tr.holeX, eased);
        drawY = _lerp(tr.startY, tr.holeY, eased);
        const s = 1 - eased * 0.85; // shrink toward 0.15
        scaleX = s;
        scaleY = s;
        break;
      }
      case 'landing': {
        const t = Math.min(tr.timer / LAND_DURATION, 1);
        const eased = t * t; // ease-in: accelerates downward, harsh stop
        drawX = this.player.x;
        drawY = this.player.y - LAND_DROP_HEIGHT * (1 - eased);
        scaleX = _lerp(0.6, 1, eased);
        scaleY = _lerp(0.6, 1, eased);
        break;
      }
      case 'squash': {
        const t = Math.min(tr.timer / SQUASH_DURATION, 1);
        drawX = this.player.x;
        drawY = this.player.y;
        scaleX = _lerp(1.4, 1, t);
        scaleY = _lerp(0.6, 1, t);
        break;
      }
      default:
        return;
    }

    const w = width * scaleX;
    const h = height * scaleY;
    ctx.fillStyle = color;
    ctx.fillRect(drawX - w / 2, drawY - h / 2, w, h);
  }

  onInput(event) {
  }
}

function _lerp(a, b, t) {
  return a + (b - a) * t;
}

export { GameplayScene };
